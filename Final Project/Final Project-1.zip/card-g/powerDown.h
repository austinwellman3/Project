#pragma once
#include"Card.h"

 
/*
	An inherited class powerDownCard from card class who purpose is to decrease the opponent's value
*/

class powerDownCard : public Card {
private:
	int power;
public:
	powerDownCard(cardType, string, int);
	void printCard() override;
	void setPower(int) override;
	void fileCard(ofstream & file) override;
	int getPower() override;
};