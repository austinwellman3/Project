#pragma once
#include <iostream>
#include <fstream>
#include <strings.h>
#include <stdio.h>
//#include <windows.h>

/*
	Card.h header files that contains declaration of class Card and it's member functions.
	The card has 3 types, 
	1. Power up : that increase your power to the card value
	2. Power down: that decrease your opponent's power to the card value
	3. Steal: that steal random card from opponent's hand and add to your hand.
*/
 
using namespace std;
enum cardType{powerUp,powerDown,steal,None}; 

struct temp_data
{
	ofstream * my_file;
};

class Card {
private:
	cardType cardT;
	string cardName;
public:
	Card();
	Card(cardType, string);
	virtual void printCard() = 0;
	
	
	 
	virtual void  fileCard(ofstream & file) = 0;



	virtual int getPower() = 0;
	virtual void setPower(int) = 0;
	void setType(cardType);
	void setName(string);
	cardType getcardType();
	string getcartName();
};
