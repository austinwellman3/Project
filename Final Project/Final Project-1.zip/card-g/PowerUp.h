#pragma once
#include"Card.h"

 /*
	An inherited class powerUpCard from card class who purpose is to increase the opponent's value
*/

class powerUpCard : public Card{
private:
	int power;
public:
	powerUpCard(cardType, string, int);
	void printCard() override;
	void setPower(int) override;
	void  fileCard(ofstream & file) override;
	int getPower() override;
};