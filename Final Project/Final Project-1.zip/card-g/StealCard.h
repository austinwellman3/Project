#pragma once
#include"Card.h"

 
/*
	An inherited class steal from card class who purpose is to get random card and append it to your hand
*/

class stealCard : public Card {
private:
public:
	stealCard(cardType, string);
	void printCard() override;
	void fileCard(ofstream & file) override;
	void setPower(int) override;
	int getPower() override;

};