#pragma once
#include "powerDown.h"
#include "PowerUp.h"
#include "StealCard.h"
 

/*
	cardFactory header file that is actually a Factory design pattern to produce only one card that is needed.
	This also implements polymorphism to some point.
*/

class cardFactory {
private:
	Card *factoryCard;
public:
	cardFactory(cardType);
	Card *getCard();
	~cardFactory();
};