﻿#include "Users.h"

// Getting method for name
string User::get_name()
{
	return name;
}

// Getting method for guess
string Partner::get_guess()
{
	return guess;
}

// Set method for guess
void Partner::set_guess(string g)
{
	this->guess = g;
}

