﻿//current source file to be included only once in a single compilation
#pragma once
#include <string>

using namespace std;

class User
{
protected:
	// Store name
	string name;
public:
	// Initialize user class
	User(const string& name)
		: name(name)
	{
	}
	// Get name
	string get_name();
};

class Partner:public User
{
private:
	// Store guess value
	string guess;
public:
	// Initialize partner class
	Partner(const string& cs):User(cs){}
	// Set guess
	void set_guess(string g);
	// Get guess
	string get_guess();
};