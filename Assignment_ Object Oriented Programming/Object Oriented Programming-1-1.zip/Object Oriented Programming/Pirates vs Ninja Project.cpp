//Pirates vs Ninja Project

#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>
#include <string>

using namespace std;

class GameStructure	//GameStructure Class
{
	public:
	
	int RandomRoll() // RandomRoll returns a number > 0 and <101
	{
		srand (time(NULL));
		return rand() % 101; //Returning number ranging from 0-100
	}	
	// Pure Virtual Function 
    virtual void Help() = 0;//A pure virtual method called Help in the GameStructure class
	
};


class Character : public GameStructure	//Character class which inherits from the GameStructure class
{
	private:
		int Health;	//One private property called Health
	public:
		string Name;	//public property Name
		
		int setHealth(int Health)	//setter public method in the Character superclass to update private Health property
		{
			if(Health <= 0) //the setter method check health before setting the value, if the new Health value will be less than zero, then set the property Health to zero and display "Character has Expired..." to the screen
			{
				cout<<Name<<" Character has Expired..."<<endl;
				this->Health = 0;
				return -1;
			}
			this->Health = Health;
			return 1;
		}
		
		int getHealth()//getter method in the Character superclass to access private Health property
		{
			return Health;	
		}	
		
		voidTalk(string stuffToSay)//using Overloading Polymorphism in the Character class
		{
			cout<<Name<<"said: "<<stuffToSay<<endl;
		}
		
		void Talk(string name, string stuffToSay)//using Overloading Polymorphism in the Character class
		{
			cout<<Name<<"said: "<<stuffToSay<<endl;
		}
		
		virtual int attack()//A virtual attack method in the Character class that returns 10 hit points
		{
			return 10;
		}
		
		void Help(){};
};


class Ninja : public Character
{
	public:
		
		Ninja(string name)//A constructor for both subclasses of the  Character class to initialize all public and private properties in the Character class and subclasses
		{
			this->Name = name;
		}
		
		void ThrowStars() //A method called ThrowStars in the Ninja class which outputs the phrase to the screen "I am throwing stars!";
		{
			cout<<"I am throwing stars!"<<endl;
		}
		
		int attack()//An override attack method in Ninja class of the Character class using Overriding Polymorphism and set its attack return values at 25 hit points
		{
			return 25;
		}
		
		void Help()//Override the Help method in the Character class
		{
			cout << "Ninja's are really cool, you can use them to throw stars!" << endl;
		}	
};

class Pirate : public Character
{
	public:
		
		Pirate(string name)	//A constructor for both subclasses of the  Character class to initialize all public and private properties in the Character class and subclasses
		{
			this->Name = name;
		}
		
		void ThrowStars()//A method called UseSword in the Pirate class which outputs to the screen "I am Swooshing my Sword!".
		{
			cout<<"I am Swooshing my Sword!"<<endl;
		}
		
		int attack()//An override attack method in Pirate class of the Character class using Overriding Polymorphism and set its attack return values at 25 hit points
		{
			return 25;
		}
		
		void Help()//Override the Help method in the Character class
		{
			cout << "Pirates are really dangerous, you can use them to attack with their swords!" << endl;
		}	
			
};




int main()
{
	int choice;	//For the user's choice input
	Character *c1 = new Ninja("White Belt Ninja"); //Using polymorphism to create a Ninja 
	Character *c2 = new Pirate("The Reaper");	   //Using polymorphism to create a Ninja 
	c1->setHealth(150);	//Setting health to 150
	c2->setHealth(150);
	while(true)
	{
		//display a cool intro to the game
		cout<<"Press 1 for Attack on Ninja.\nPress 2 to Attack on Pirate.\nPress 3 to perform Ninja's Special Attack.\nPress 4 to perform Pirate's Special Attack.\nPress 5 to view Ninja's Help.\nPress 6 to view Pirate's Help.\nPress 7 to Exit.\n";
		cin>>choice;
		if(choice == 1) //Pirate attacking Ninja
		{
			int status = c1->setHealth(c1->getHealth()-c2->attack());	//Character 1 taking damage from Character 2
			if(status == -1)//If setHealth return -1 then it means that the character 2 has expired
			{
				cout<<c2->Name<<" is the winner! Thankyou for playing."<<endl;
				break;//Breaking the loop i.e. Ending the game
			}
			cout<<c2->Name<<" caused a damage of "<<c2->attack()<<" on "<<c1->Name<<endl;
			cout<<c1->Name<<" remaning health: "<<c1->getHealth()<<endl;
		}
		else if(choice == 2) //Ninja attacking Pirate
		{
			int status = c2->setHealth(c2->getHealth()-c1->attack());	//Character 2 taking damage from Character 1
			if(status == -1)	//If setHealth return -1 then it means that the character 2 has expired
			{
				cout<<c1->Name<<" is the winner! Thankyou for playing."<<endl;
				break; //Breaking the loop i.e. Ending the game
			}
			cout<<c1->Name<<" caused a damage of "<<c1->attack()<<" on "<<c2->Name<<endl;
			cout<<c2->Name<<" remaning health: "<<c2->getHealth()<<endl;
		}
		else if(choice == 3)//Ninja's Special Attack
		{
			int attack = c1->RandomRoll();//Using the RandomRoll function to perform a special attack damage from 0-100
			int status = c2->setHealth(c2->getHealth()-attack);//Character 2 taking damage from Character 1
			if(status == -1)//If setHealth return -1 then it means that the character 2 has expired
			{
				cout<<c1->Name<<" is the winner! Thankyou for playing."<<endl;
				break;//Breaking the loop i.e. Ending the game
			}
			cout<<c1->Name<<" caused a damage of "<<c1->attack()<<" on "<<c2->Name<<endl;
			cout<<c2->Name<<" remaning health: "<<c2->getHealth()<<endl;
		}
		else if(choice == 4)//Pirate's Special Attack
		{
			int attack = c2->RandomRoll();//Using the RandomRoll function to perform a special attack damage from 0-100
			int status = c1->setHealth(c1->getHealth()-attack);//Character 1 taking damage from Character 2
			if(status == -1)//If setHealth return -1 then it means that the character 1 has expired
			{
				cout<<c2->Name<<" is the winner! Thankyou for playing."<<endl;
				break;//Breaking the loop i.e. Ending the game
			}
			cout<<c2->Name<<" caused a damage of "<<attack<<" on "<<c1->Name<<endl;
			cout<<c1->Name<<" remaning health: "<<c1->getHealth()<<endl;
		}
		else if(choice == 5)
		{
			c1->Help(); //Displaying the help of Character 1
		}
		else if(choice == 6)
		{
			c2->Help();//Displaying the help of Character 2
		}
		else if(choice == 7)
		{
			cout<<"Thank you for playing Pirates vs Ninja.GoodBye!"<<endl;
			break;//Breaking the loop i.e. Ending the game
		}
		else
		{
			cout<<"Please select a valid choice."<<endl;
			cin.clear(); //Clearing the cin buffer to take input again in the loop
         	cin.ignore();// discard 'bad' character(s)
         	continue;//Entering the loop again
		}
		
	}

}
